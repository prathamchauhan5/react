import CompoB from "./CompoB";

export default function CompoA(){

    return(
    <div>

        <CompoB/>
    </div>
    )
}
