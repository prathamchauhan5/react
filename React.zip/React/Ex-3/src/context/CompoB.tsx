import CompoC from "./CompoC";




export default function CompoB(){
    

    return(
    <div>
        
        <CompoC/>
    
    </div>
    )
}
