
import { Ag_grid}  from './component/Ag_grid';

function App() {
  return (
       <Ag_grid/> 
    
  );
}

export default App;
