
import Time from './component/EX1'
import Todo from './component/EX2'

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <Time/> */}
        <Todo></Todo>
      </header>
    </div>
  );
}

export default App;
